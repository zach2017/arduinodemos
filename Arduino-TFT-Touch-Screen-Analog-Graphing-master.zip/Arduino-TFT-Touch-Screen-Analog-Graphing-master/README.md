# Arduino-TFT-Touch-Screen-Analog-Graphing
This sketch allows graphing of two analog signals on a TFT Touch Screen. You will need to download and install 3 libraries. There is an instructable available here: http://www.instructables.com/id/Arduino-Analog-Signal-Graphing-on-a-TFT-Touch-Scre/   
